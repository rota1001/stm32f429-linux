#!/bin/bash
# DRM Test - Run Linux kernel on QEMU Cortex-A virt machine with DRM/virtio-gpu
#
# Prerequisites:
#   - Linux kernel built: linux-7.0/arch/arm/boot/zImage
#   - Rootfs: rootfs.cpio.gz
#   - QEMU: qemu-system-arm
#
# This boots a minimal Linux kernel with virtio-gpu and verifies /dev/dri/card0

set -e

KERNEL="./zImage"
INITRD="./rootfs.cpio.gz"

echo "=== DRM Test QEMU ==="
echo "Kernel: ${KERNEL}"
echo "Initrd: ${INITRD}"
echo

exec qemu-system-arm \
  -M virt,highmem-ecam=off \
  -cpu max \
  -m 128M \
  -kernel "${KERNEL}" \
  -initrd "${INITRD}" \
  -append "console=ttyAMA0 video=240x320" \
  -device virtio-gpu-pci \
  -device virtio-keyboard-pci \
  -device virtio-mouse-pci \
  -display gtk \
  -serial stdio
